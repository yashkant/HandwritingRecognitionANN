##Open Source - FileUp
FileUp is an Android WebView Image Upload Application, to give idea to new programmers how to deal with different Android versions WebView.

##Getting Started
Project contains and complete Android Application that you can download and use directly.
To edit project codes, better use Latest Android Studio.

##Contribute
Contributions are always welcome!

##License
This project is licensed under the terms of the [MIT license](https://opensource.org/licenses/MIT).

##More about Project OS
Project OS (OpenSource) is not a big deal to understand. I always wanted to share what I learned through my experiences so please be free to ask questions and help.
Mail me: mgks@infeeds.com
Support: https://infeeds.com/@mgks

##Happy Coding
If not always. Sometimes try to share code snippets you know better. Because sharing is caring :)

NOTE: Android 4.4 doesn't support webview upload default method and it's a permanent bug as no more KitKat updates are going to be made.