{
"user": [
{
"id": "001",
"name": "Raj Amal",
"email": "raj.amalw@gmail.com"
}
]
}
